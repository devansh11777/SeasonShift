"""
seed_data.py
------------
Populates the database with realistic sample data for SeasonShift.

Run with:  python manage.py shell < seed_data.py

Creates:
  - 6 Indian destinations
  - 12 months of crowd data for each (realistic seasons)
  - 12–15 hotel/package listings
  - Demo hotel manager user
  - Demo traveler user
  - 1 superuser (admin)
"""

import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'seasonshift.settings')
django.setup()

from django.contrib.auth.models import User
from tourism.models import Destination, MonthlyCrowd, Listing

print("🌱 Starting seed data creation...")

# =============================================================================
# Clean up existing data to allow re-running
# =============================================================================
Listing.objects.all().delete()
MonthlyCrowd.objects.all().delete()
Destination.objects.all().delete()
User.objects.filter(username__in=['admin', 'manager1', 'traveler1']).delete()

# =============================================================================
# Create Users
# =============================================================================
print("👤 Creating users...")

# Superuser – full access to everything
admin = User.objects.create_superuser(
    username='admin',
    email='admin@seasonshift.com',
    password='admin123!'
)
admin.first_name = 'Admin'
admin.last_name = 'SeasonShift'
admin.save()

# Hotel Manager – can manage their own listings
manager = User.objects.create_user(
    username='manager1',
    email='manager@seasonshift.com',
    password='manager123!',
    first_name='Rajesh',
    last_name='Sharma'
)
manager.is_staff = True  # Allow admin panel access
manager.save()

# Demo Traveler – regular user who can book
traveler = User.objects.create_user(
    username='traveler1',
    email='traveler@seasonshift.com',
    password='traveler123!',
    first_name='Priya',
    last_name='Patel'
)

print(f"  ✓ Created: {admin.username}, {manager.username}, {traveler.username}")

# =============================================================================
# Assign Hotel Manager group (if setup_groups.py has been run)
# =============================================================================
from django.contrib.auth.models import Group
try:
    hm_group = Group.objects.get(name='Hotel Manager')
    manager.groups.add(hm_group)
    print("  ✓ Added manager1 to 'Hotel Manager' group")
except Group.DoesNotExist:
    print("  ℹ️  'Hotel Manager' group not found – run setup_groups.py first")


# =============================================================================
# Create Destinations with realistic descriptions
# =============================================================================
print("\n🗺️  Creating destinations...")

destinations_data = [
    {
        'name': 'Manali',
        'state': 'Himachal Pradesh',
        'description': (
            'Nestled in the Kullu Valley at 2,050m, Manali is a Himalayan resort '
            'town famous for adventure sports, pine forests and snow-capped peaks. '
            'Visit in autumn or spring for lower crowds and better deals. The Rohtang '
            'Pass, Solang Valley and Old Manali are must-sees.'
        ),
        'image_url': 'https://images.unsplash.com/photo-1626621331169-5f34be280ed9?w=800',
        # Crowd: High in May-Jun (summer tourists) and Dec-Jan (snow lovers)
        # Low in Sep-Oct (after monsoon), Mar-Apr (spring)
        'crowds': {
            1: 'High',  # January – snow tourists
            2: 'Medium',
            3: 'Low',   # March – pre-season
            4: 'Low',   # April – spring
            5: 'High',  # May – summer school holidays
            6: 'High',  # June – peak summer
            7: 'Medium', # July – monsoon
            8: 'Medium', # August – monsoon
            9: 'Low',   # September – post-monsoon, great weather
            10: 'Low',  # October – golden autumn
            11: 'Medium',
            12: 'High',  # December – Christmas/New Year snow
        }
    },
    {
        'name': 'Goa',
        'state': 'Goa',
        'description': (
            'India\'s smallest state and party capital, Goa is famous for its '
            'golden beaches, Portuguese heritage, vibrant nightlife and seafood. '
            'The monsoon season (June–September) sees dramatically fewer tourists '
            'but lush green landscapes – a hidden gem for budget travellers. '
            'North Goa has the party beaches; South Goa is quieter and cleaner.'
        ),
        'image_url': 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=800',
        # Peak: Nov–Feb (winter tourists from India and abroad)
        # Low: Jun–Sep (monsoon – heavy rains but beautiful)
        'crowds': {
            1: 'High',  # January – peak tourist season
            2: 'High',  # February – Carnival
            3: 'Medium',
            4: 'Low',   # April – getting hot
            5: 'Low',   # May – pre-monsoon
            6: 'Low',   # June – monsoon
            7: 'Low',   # July – heavy monsoon
            8: 'Low',   # August – monsoon
            9: 'Low',   # September – end of monsoon
            10: 'Medium', # October – post-monsoon
            11: 'High',  # November – season starts
            12: 'High',  # December – Christmas/New Year peak
        }
    },
    {
        'name': 'Jaipur',
        'state': 'Rajasthan',
        'description': (
            'The Pink City of India, Jaipur is the gateway to the Golden Triangle '
            'and Rajasthan\'s royal heritage. Home to the Amber Fort, City Palace, '
            'Hawa Mahal and vibrant bazaars. Summers are brutal (45°C+) which keeps '
            'tourists away – great for budget travellers who don\'t mind heat. '
            'The best off-season deals are in May, June and July.'
        ),
        'image_url': 'https://images.unsplash.com/photo-1477587458883-47145ed94245?w=800',
        'crowds': {
            1: 'High',  # January – Literature Festival and cool weather
            2: 'High',  # February – Holi preparations
            3: 'Medium', # March – warming up
            4: 'Low',   # April – getting hot
            5: 'Low',   # May – very hot, great deals
            6: 'Low',   # June – monsoon, very hot
            7: 'Low',   # July – monsoon
            8: 'Medium', # August – monsoon easing
            9: 'Medium', # September – post-monsoon
            10: 'High',  # October – Diwali season
            11: 'High',  # November – prime tourist season
            12: 'High',  # December – peak
        }
    },
    {
        'name': 'Kerala Backwaters',
        'state': 'Kerala',
        'description': (
            'The backwaters of Kerala – a network of canals, rivers, lakes and inlets '
            'stretching 900 km along the Arabian Sea coast – are one of India\'s most '
            'unique ecosystems. Take a houseboat from Alleppey or Kumarakom and drift '
            'through paddy fields and coconut groves. Monsoon is surprisingly magical '
            'here – the green is at its most vivid and prices are at their lowest.'
        ),
        'image_url': 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=800',
        'crowds': {
            1: 'High',
            2: 'High',
            3: 'Medium',
            4: 'Medium',
            5: 'Low',   # May – pre-monsoon
            6: 'Low',   # June – SW monsoon arrives
            7: 'Low',   # July – heavy monsoon
            8: 'Low',   # August – Onam preparations (locals travel, fewer tourists)
            9: 'Medium', # September – Onam, end of monsoon
            10: 'Medium',
            11: 'High',
            12: 'High',
        }
    },
    {
        'name': 'Rishikesh',
        'state': 'Uttarakhand',
        'description': (
            'The Yoga Capital of the World, Rishikesh sits at the foothills of the '
            'Himalayas on the banks of the Ganga. Famous for white-water rafting, '
            'bungee jumping, yoga ashrams and the Beatles Ashram. The monsoon makes '
            'rafting more thrilling (and cheaper!). Winters see fewer tourists but '
            'spiritual seekers come year-round.'
        ),
        'image_url': 'https://images.unsplash.com/photo-1590080875852-4a28e9c3a910?w=800',
        'crowds': {
            1: 'Medium',
            2: 'Medium',
            3: 'High',   # March – International Yoga Festival
            4: 'High',   # April – ideal weather
            5: 'High',   # May – pre-monsoon adventure season
            6: 'Medium', # June – early monsoon
            7: 'Low',    # July – heavy monsoon, rafting restricted
            8: 'Low',    # August – monsoon
            9: 'Medium', # September – end of monsoon
            10: 'High',  # October – post-monsoon, golden season
            11: 'Medium',
            12: 'Medium',
        }
    },
    {
        'name': 'Udaipur',
        'state': 'Rajasthan',
        'description': (
            'The City of Lakes, Udaipur is one of Rajasthan\'s most romantic cities. '
            'The Lake Palace (now a hotel) floating on Lake Pichola, the grand City '
            'Palace, and the colourful old city make it a photographer\'s dream. '
            'Like Jaipur, the summer months see fewer tourists and significant hotel '
            'discounts, while the lakes fill up beautifully during monsoon.'
        ),
        'image_url': 'https://images.unsplash.com/photo-1587295656906-b3c37a73ca30?w=800',
        'crowds': {
            1: 'High',
            2: 'High',
            3: 'Medium',
            4: 'Low',   # April – heating up
            5: 'Low',   # May – very hot
            6: 'Low',   # June – monsoon, lakes fill up
            7: 'Medium', # July – monsoon, scenic lakes
            8: 'Medium', # August – post-monsoon beauty
            9: 'Medium',
            10: 'High',
            11: 'High',
            12: 'High',
        }
    },
]

created_destinations = []
for data in destinations_data:
    dest = Destination.objects.create(
        name=data['name'],
        state=data['state'],
        description=data['description'],
        image_url=data['image_url']
    )
    # Create crowd data for all 12 months
    for month, level in data['crowds'].items():
        MonthlyCrowd.objects.create(
            destination=dest,
            month=month,
            crowd_level=level
        )
    created_destinations.append(dest)
    print(f"  ✓ Created destination: {dest.name} with 12 months of crowd data")

# Map for easy access
dest_map = {d.name: d for d in created_destinations}

# =============================================================================
# Create Listings (Hotels and Packages)
# =============================================================================
print("\n🏨 Creating listings...")

listings_data = [
    # --- MANALI ---
    {
        'destination': 'Manali',
        'owner': manager,
        'title': 'Snow Peak Resort & Spa',
        'listing_type': 'Hotel',
        'base_price': 4500,
        'description': (
            'Luxury mountain resort with stunning Himalayan views, indoor heated pool, '
            'spa, and bonfire evenings. Located 2 km from Mall Road. '
            'All rooms have private balconies facing the snow peaks.'
        ),
    },
    {
        'destination': 'Manali',
        'owner': manager,
        'title': 'Himalayan Adventure Package – 5 Days',
        'listing_type': 'Package',
        'base_price': 18000,
        'description': (
            '5-day adventure package including: Solang Valley skiing/sledging, '
            'Rohtang Pass excursion, river crossing, camping, bonfire, all meals, '
            'and pick-up/drop from Manali bus stand. Equipment provided.'
        ),
    },
    {
        'destination': 'Manali',
        'owner': admin,
        'title': 'Old Manali Riverside Cottage',
        'listing_type': 'Hotel',
        'base_price': 2200,
        'description': (
            'Charming wooden cottage right by the Beas River in Old Manali village. '
            'Walk to Bob Dylan Café and the vibrant café culture. '
            'Ideal for backpackers and honeymooners. Breakfast included.'
        ),
    },
    # --- GOA ---
    {
        'destination': 'Goa',
        'owner': manager,
        'title': 'Calangute Beach Villa',
        'listing_type': 'Hotel',
        'base_price': 5500,
        'description': (
            'Beachfront villa with private pool, 50m from Calangute Beach. '
            '3 bedrooms, full kitchen, butler service. '
            'Great for groups and families. Sunset views from the rooftop.'
        ),
    },
    {
        'destination': 'Goa',
        'owner': admin,
        'title': 'Goa Monsoon Magic Package – 4 Days',
        'listing_type': 'Package',
        'base_price': 12000,
        'description': (
            'Experience Goa in the green monsoon season! Package includes: '
            'beachside hotel (3 nights), spice plantation tour, Portuguese heritage '
            'walk, seafood dinner cruise, and airport transfers. Perfect off-season deal.'
        ),
    },
    {
        'destination': 'Goa',
        'owner': manager,
        'title': 'South Goa Eco Resort',
        'listing_type': 'Hotel',
        'base_price': 3800,
        'description': (
            'Peaceful eco-resort in South Goa surrounded by paddy fields and coconut '
            'groves. 10 minutes from Palolem and Colva Beach. '
            'Yoga sessions, organic meals, and cycling available. Calm and natural.'
        ),
    },
    # --- JAIPUR ---
    {
        'destination': 'Jaipur',
        'owner': manager,
        'title': 'Heritage Haveli – Pink City',
        'listing_type': 'Hotel',
        'base_price': 3200,
        'description': (
            'Restored 200-year-old haveli in the heart of the walled Pink City. '
            'Walk to Hawa Mahal and City Palace in minutes. '
            'Rooftop restaurant with views of the Pink City skyline. '
            'Authentic Rajasthani hospitality and décor.'
        ),
    },
    {
        'destination': 'Jaipur',
        'owner': admin,
        'title': 'Royal Rajasthan Golden Triangle Tour – 7 Days',
        'listing_type': 'Package',
        'base_price': 32000,
        'description': (
            '7-day package covering Delhi, Agra (Taj Mahal), and Jaipur. '
            'Includes AC car with driver, 3-star hotels, breakfast, guided monument '
            'tours, elephant ride at Amber Fort, and Jaipur bazaar shopping walk.'
        ),
    },
    # --- KERALA BACKWATERS ---
    {
        'destination': 'Kerala Backwaters',
        'owner': manager,
        'title': 'Alleppey Houseboat – Premium',
        'listing_type': 'Hotel',
        'base_price': 8000,
        'description': (
            'Luxury AC houseboat with 2 bedrooms, sun deck, and onboard chef. '
            '24-hour cruise through the Vembanad Lake and backwater canals. '
            'All meals (Kerala cuisine) included. Departs from Alleppey boat jetty.'
        ),
    },
    {
        'destination': 'Kerala Backwaters',
        'owner': admin,
        'title': 'Kerala Ayurveda & Backwater Package – 6 Days',
        'listing_type': 'Package',
        'base_price': 25000,
        'description': (
            '6-day wellness package: 2 days on a houseboat, 2 days at Ayurveda '
            'resort (Panchakarma treatments), and 2 days at Munnar tea gardens. '
            'All meals, Kathakali performance, spice garden visit included.'
        ),
    },
    # --- RISHIKESH ---
    {
        'destination': 'Rishikesh',
        'owner': manager,
        'title': 'Ganga View Yoga Retreat',
        'listing_type': 'Hotel',
        'base_price': 2800,
        'description': (
            'Peaceful ashram-style retreat on the banks of the Ganga. '
            'Morning and evening yoga sessions, meditation, vegetarian meals. '
            'Walking distance to Laxman Jhula and Ram Jhula bridges. '
            'Ideal for solo spiritual travellers.'
        ),
    },
    {
        'destination': 'Rishikesh',
        'owner': admin,
        'title': 'Adventure Sports Camp – 3 Days',
        'listing_type': 'Package',
        'base_price': 9500,
        'description': (
            '3-day adventure package: white-water rafting (Grade 3–5 rapids), '
            'bungee jumping, cliff jumping, zip-lining, and camping by the Ganga. '
            'All safety equipment, meals and experienced guides included. '
            'Min age: 14 years.'
        ),
    },
    # --- UDAIPUR ---
    {
        'destination': 'Udaipur',
        'owner': manager,
        'title': 'Lake Pichola Boutique Hotel',
        'listing_type': 'Hotel',
        'base_price': 6500,
        'description': (
            'Boutique hotel with direct lake views and rooftop pool. '
            'Walk to City Palace and Jagdish Temple. '
            'Evening boat rides to Lake Palace. Rajasthani puppet shows and '
            'folk music every evening. Breakfast and boat ride included.'
        ),
    },
    {
        'destination': 'Udaipur',
        'owner': admin,
        'title': 'Udaipur Royal Romance Package – 3 Days',
        'listing_type': 'Package',
        'base_price': 20000,
        'description': (
            '3-day package perfect for couples: Lake Palace boat tour, '
            'City Palace guided tour, sunset dinner cruise on Lake Pichola, '
            'Sajjangarh (Monsoon Palace) visit, heritage walk, and village safari. '
            'Stay in a heritage property. All meals included.'
        ),
    },
    {
        'destination': 'Udaipur',
        'owner': manager,
        'title': 'Aravalli Hills Budget Stay',
        'listing_type': 'Hotel',
        'base_price': 1500,
        'description': (
            'Budget-friendly guesthouse in the old city with rooftop views of '
            'the Aravalli hills and Lake Fateh Sagar. '
            'Simple, clean rooms. Great value for solo backpackers. '
            'Common kitchen available. Free bicycle rental.'
        ),
    },
]

for data in listings_data:
    listing = Listing.objects.create(
        destination=dest_map[data['destination']],
        owner=data['owner'],
        title=data['title'],
        listing_type=data['listing_type'],
        base_price=data['base_price'],
        description=data['description'],
    )
    print(f"  ✓ Created listing: {listing.title} @ {listing.destination.name}")

print(f"\n✅ Seed data complete!")
print(f"   • {Destination.objects.count()} destinations")
print(f"   • {MonthlyCrowd.objects.count()} monthly crowd records")
print(f"   • {Listing.objects.count()} listings")
print(f"   • {User.objects.count()} users")
print("\n🔑 Demo credentials:")
print("   Admin:   admin / admin123!")
print("   Manager: manager1 / manager123!")
print("   Traveler: traveler1 / traveler123!")

