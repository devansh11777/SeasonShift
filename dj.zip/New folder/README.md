# 🌴 SeasonShift – Smart Off-Season Tourism Platform

> **University Project for the Course:** *"Web Development in Python using Django"*  
> **Architecture:** Pure Django MTV (Model-Template-View) with Function-Based Views (FBVs)  
> **Styling:** Bootstrap 5 (via CDN) + Bootstrap Icons  
> **Database:** SQLite  

---

## 📖 1. Project Overview & Problem Statement

### The Problem
- **Hotels & Tour Operators:** Suffer from extreme seasonality. During off-peak months, hotels experience low occupancy rates, yet must pay fixed staff and operational overheads.
- **Travelers:** Face inflated peak-season prices, overcrowded attractions, long queues, and compromised travel experiences.

### The Solution: SeasonShift
**SeasonShift** is a win-win tourism marketplace:
1. **Dynamic Seasonal Pricing:** Automatically computes off-season discounts based on crowd levels:
   - 🟢 **Low Crowd:** **30% Discount** (incentivizes bookings during slumps)
   - 🟡 **Medium Crowd:** **15% Discount** (balanced shoulder season)
   - 🔴 **High Crowd:** **0% Discount** (standard peak price)
2. **Crowd Intelligence:** Features a visual 12-month crowd calendar for every destination.
3. **Smart Features:** Session-based wishlist, cookie-based "Recently Viewed" history, role-based admin isolation for hotel managers, and validated booking workflows with Post/Redirect/Get (PRG) alerts.

---

## 🎯 2. Technology Constraints & Academic Compliance

This project is built strictly to academic specifications without overcomplicating with third-party frameworks:
- ✅ **No Django REST Framework (DRF):** Only native Django views and standard `JsonResponse`.
- ✅ **No JavaScript Frameworks (React, Vue, Angular):** Plain HTML5 with Bootstrap 5 CDN.
- ✅ **No External APIs or Payment Gateways:** Self-contained logic with clean simulation.
- ✅ **No Docker:** Runs directly with standard Python 3 and Django.
- ✅ **Clean, Well-Commented Code:** Designed so university students can read, explain, and defend every line during an viva or presentation.

---

## 🗂️ 3. Project Structure

```text
SeasonShift/
├── manage.py                   # Django CLI management script
├── requirements.txt            # Project dependencies (Django)
├── seed_data.py                # Database population script (destinations, crowds, listings, users)
├── setup_groups.py             # Role-based permissions setup script ("Hotel Manager")
├── db.sqlite3                  # SQLite database file
├── README.md                   # Complete documentation & viva guide
│
├── seasonshift/                # Project Configuration
│   ├── __init__.py
│   ├── settings.py             # Settings: apps, middleware, DTL, auth URLs, logging
│   ├── urls.py                 # Root URL configuration + custom 404/500 handlers
│   ├── wsgi.py                 # WSGI entry point
│   └── asgi.py                 # ASGI entry point
│
├── tourism/                    # Main Tourism Application
│   ├── __init__.py
│   ├── admin.py                # ModelAdmin, Inlines, and Hotel Manager isolation
│   ├── apps.py                 # TourismConfig
│   ├── forms.py                # RegistrationForm, DestinationSearchForm, BookingForm (with validators)
│   ├── models.py               # Destination, MonthlyCrowd, Listing, Booking models
│   ├── tests.py                # 34 automated unit & integration tests
│   ├── urls.py                 # URL patterns (path + regex re_path)
│   ├── views.py                # 100% Function-Based Views (FBVs)
│   └── migrations/             # Database migrations
│       ├── 0001_initial.py
│       └── __init__.py
│
└── templates/                  # Django Template Language (DTL) Templates
    ├── base.html               # Master layout with responsive navbar, messages, footer
    ├── 404.html                # Custom 404 Page Not Found error page
    ├── 500.html                # Custom 500 Internal Server Error page
    ├── includes/
    │   └── listing_card.html   # Reusable listing card component
    └── tourism/
        ├── home.html               # Landing page with hero, value prop, featured destinations & recent cookies
        ├── destination_list.html   # Searchable and filterable destination directory
        ├── destination_detail.html # 12-month crowd calendar and destination hotel/package listings
        ├── listing_detail.html     # Dynamic price calculator for chosen month + set_cookie
        ├── book_listing.html       # Booking form with validation and CSRF protection
        ├── my_bookings.html        # Authenticated user's booking history
        ├── offseason_deals.html    # Regex-routed view (/offseason/YYYY-MM/) for month discounts
        ├── wishlist.html           # Session-stored wishlist
        ├── register.html           # Sign-up page
        ├── login.html              # Login page with demo credentials
        └── partials/
            └── listing_card.html   # Reusable partial for listing cards
```

---

## 📚 4. Syllabus-Unit Mapping Table

This table maps every project component to typical university course units for **Web Development in Python using Django**:

| Course Unit | Key Concepts Taught | Implementation in SeasonShift |
| :--- | :--- | :--- |
| **Unit 1: Django Architecture & Setup** | MTV Pattern, virtual environments, `settings.py`, `manage.py`, project vs app structure | `seasonshift/settings.py` (INSTALLED_APPS, TEMPLATES, DATABASES), virtual environment setup, standalone execution scripts |
| **Unit 2: Models & Django ORM** | Models, Fields (CharField, TextField, URLField, DecimalField, IntegerField, DateField, ForeignKey), `unique_together`, `on_delete=models.CASCADE`, custom model methods, `__str__` | `Destination`, `MonthlyCrowd`, `Listing` (with `get_discount_percent` & `get_price_for_month`), `Booking` |
| **Unit 3: Views & URL Dispatching** | Function-Based Views (FBVs), `path()`, `re_path()` with named regex groups `(?P<var>regex)`, `HttpResponse`, `JsonResponse`, `redirect()`, `get_object_or_404()` | 16 views in `tourism/views.py`, regex in `/offseason/(?P<year>[0-9]{4})-(?P<month>[0-9]{2})/`, API in `/api/crowd/<dest_id>/<month>/` |
| **Unit 4: Django Template Language (DTL)** | Template inheritance (`{% extends %}`, `{% block %}`), loops (`{% for %}`), conditionals (`{% if/elif/else %}`), `{% empty %}`, `{% url %}`, `{% include %}`, filters (`date`, `floatformat`, `truncatewords`, `pluralize`) | `base.html` master template, `includes/listing_card.html` partial, badges for Low/Medium/High crowd, price strikethrough styling |
| **Unit 5: Forms & Validation** | `forms.Form`, `forms.ModelForm`, `clean()`, `clean_<field>()`, `ValidationError`, CSRF protection (`{% csrf_token %}`), Post/Redirect/Get (PRG) pattern | `RegistrationForm` (extends `UserCreationForm`), `DestinationSearchForm`, `BookingForm` (validates check-in not past, checkout > checkin, phone 10 digits, guests 1-10) |
| **Unit 6: Sessions & Cookies** | Server-side sessions (`request.session`), HTTP cookies (`response.set_cookie()`, `request.COOKIES`), persistence without login | Wishlist stored in `request.session['wishlist']`; Recently viewed listings stored in `recently_viewed` cookie |
| **Unit 7: Authentication & Permissions** | Django Auth (`User`, `login`, `logout`, `authenticate`, `@login_required`), groups, ModelAdmin permissions, queryset filtering | Login/logout/registration, `@login_required` on booking views, "Hotel Manager" group, `get_queryset` and `save_model` isolation |
| **Unit 8: Testing & Debugging** | Django `TestCase`, test `Client`, Model tests, Form tests, View tests, Django shell, logging, custom error handlers | 34 passing tests in `tourism/tests.py`, console logging via `settings.LOGGING`, custom `404.html` and `500.html` |

---

## 🗄️ 5. ER-Style Model Description & Schema

```text
+---------------------+           +------------------------+
|     Destination     |           |      MonthlyCrowd      |
+---------------------+           +------------------------+
| id (PK)             |<----+     | id (PK)                |
| name                |     +-----| destination_id (FK)   |
| state               |           | month (1-12)           |
| description         |           | crowd_level (L/M/H)    |
| image_url           |           +------------------------+
+---------------------+           Constraint: (dest, month) UNIQUE
      |
      | 1:N
      v
+---------------------+           +------------------------+
|       Listing       |           |          User          |
+---------------------+           +------------------------+
| id (PK)             |     +---->| id (PK)                |
| destination_id (FK) |     |     | username, password...  |
| owner_id (FK)-------+-----+     +------------------------+
| title               |               |                 ^
| listing_type        |               | 1:N             |
| base_price          |<-------+      v                 |
| description         |        |  +---------------------+
+---------------------+        |  |       Booking       |
                               |  +---------------------+
                               |  | id (PK)             |
                               |  | user_id (FK)--------+
                               +--| listing_id (FK)     |
                                  | check_in, check_out |
                                  | guests, phone       |
                                  | final_price         |
                                  | status (Pend/Conf)  |
                                  | created_at          |
                                  +---------------------+
```

### Detailed Field Breakdown
1. **Destination:**
   - `name`: `CharField(max_length=200)`
   - `state`: `CharField(max_length=100)`
   - `description`: `TextField()`
   - `image_url`: `URLField(max_length=500)`
2. **MonthlyCrowd:**
   - `destination`: `ForeignKey(Destination, on_delete=CASCADE, related_name='crowd_levels')`
   - `month`: `IntegerField(choices=1..12)`
   - `crowd_level`: `CharField(choices=['Low', 'Medium', 'High'])`
   - `unique_together`: `('destination', 'month')`
3. **Listing:**
   - `destination`: `ForeignKey(Destination, on_delete=CASCADE, related_name='listings')`
   - `owner`: `ForeignKey(User, on_delete=CASCADE, related_name='listings')`
   - `title`: `CharField(max_length=300)`
   - `listing_type`: `CharField(choices=['Hotel', 'Package'])`
   - `base_price`: `DecimalField(max_digits=10, decimal_places=2)`
   - `description`: `TextField()`
   - **Methods:**
     - `get_discount_percent(month)`: Returns `30` (Low), `15` (Medium), `0` (High).
     - `get_price_for_month(month)`: Returns discounted `Decimal` value.
4. **Booking:**
   - `user`: `ForeignKey(User, on_delete=CASCADE, related_name='bookings')`
   - `listing`: `ForeignKey(Listing, on_delete=CASCADE, related_name='bookings')`
   - `check_in`: `DateField()`
   - `check_out`: `DateField()`
   - `guests`: `IntegerField()`
   - `phone`: `CharField(max_length=15)`
   - `final_price`: `DecimalField(max_digits=10, decimal_places=2)`
   - `status`: `CharField(choices=['Pending', 'Confirmed'], default='Pending')`
   - `created_at`: `DateTimeField(auto_now_add=True)`

---

## ⚡ 6. Quick Setup & Execution Guide

### Prerequisites
- Python 3.10+ (tested on Python 3.10 through Python 3.14)
- Git (optional)

### Step 1: Create and Activate Virtual Environment
```bash
# Windows (PowerShell or Command Prompt)
python -m venv venv
.\venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Run Database Migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### Step 4: Setup Groups & Permissions
```bash
python setup_groups.py
```
*(Creates the **Hotel Manager** group with isolated listing management and booking view privileges).*

### Step 5: Seed Sample Data
```bash
python seed_data.py
```
*(Populates 6 iconic Indian destinations, 72 monthly crowd records, 15 hotel & package listings, and 3 demo accounts).*

### Step 6: Run Automated Tests
```bash
python manage.py test
```
*(Runs 34 tests across models, forms, session wishlist, regex URLs, cookies, and views).*

### Step 7: Start the Development Server
```bash
python manage.py runserver
```
Open your browser and navigate to: `http://127.0.0.1:8000/`

---

## 🔑 7. Demo Accounts & Credentials

| Role | Username | Password | Privileges |
| :--- | :--- | :--- | :--- |
| **Superuser / Admin** | `admin` | `admin123!` | Full admin panel access (`/admin/`), can view & edit all destinations, listings, bookings, and users |
| **Hotel Manager** | `manager1` | `manager123!` | Admin panel access (`/admin/`), filtered by permission: can only view & edit listings they personally own; view bookings |
| **Traveler** | `traveler1` | `traveler123!` | Regular user: browse, add to wishlist, book listings, view `/my-bookings/` |

---

## 🛠️ 8. Debugging & Development Techniques Used

During the development of SeasonShift, three core debugging methods were utilized:

1. **Django's Interactive Debug Page (`DEBUG = True`):**
   - Enabled detailed exception tracebacks in the browser during development.
   - Used to verify context dictionaries, HTTP request headers, and template compilation paths.
2. **The Django Shell (`python manage.py shell`):**
   - Used to test ORM queries interactively:
     ```python
     from tourism.models import Listing
     l = Listing.objects.first()
     print(l.get_discount_percent(6))  # Test off-season discount
     print(l.get_price_for_month(6))   # Test price calculation
     ```
   - Used to test group assignment and permission checks before building views.
3. **Console Logging & Print Debugging (`LOGGING` in `settings.py`):**
   - Configured console logging handler at `WARNING` level for Django core and `DEBUG` level for `tourism`.
   - Logged critical lifecycle events: user logins, booking creations, and cookie parsing warnings.

---

## 🎤 9. How to Present (5-Minute Viva / Demo Flow)

Follow this 5-minute step-by-step walkthrough during your evaluation:

### ⏱️ Minute 1: Introduction & Problem Statement
- **Open:** `http://127.0.0.1:8000/`
- **Say:** *"SeasonShift solves the tourism seasonality problem. Hotels struggle with empty rooms off-peak, while travelers face high prices during peak times. SeasonShift links crowd levels to discounts: 30% for Low crowd, 15% for Medium crowd, and 0% for High crowd."*
- **Show:** The landing page hero section, the 3 value-proposition cards, and the featured destinations grid.

### ⏱️ Minute 2: Search, Filters & The 12-Month Crowd Calendar
- **Navigate to:** `Destinations` (`/destinations/`)
- **Action:** Search for `"Goa"` or filter by month (e.g., Month `6` for June).
- **Click into:** **Goa** (`/destination/2/`)
- **Show:**
  - The **12-Month Crowd Calendar** table with colored badges:
    - 🟢 Green badges for Low crowd (June–September monsoon) displaying `30% off`.
    - 🟡 Yellow badges for Medium crowd (March, October).
    - 🔴 Red badges for Peak High crowd (November–February).
  - Note the developer info box showing the JSON API: `/api/crowd/2/6/` (open in a new tab to show native `JsonResponse`).

### ⏱️ Minute 3: Listing Detail, Dynamic Month Pricing & Cookies
- **Click into:** **Calangute Beach Villa** (`/listing/4/`)
- **Show:**
  - The base price crossed out (`₹5,500.00`) next to the discounted price (`₹3,850.00` with `30% OFF`).
  - Use the month dropdown to switch to **December** (Peak Season): the price updates to full `₹5,500.00` and the badge switches to `🔴 High`.
- **Show Cookies & Wishlist:**
  - Click **Save to Wishlist** ❤️: Explain that the wishlist is stored in `request.session['wishlist']` without requiring a login.
  - Return to **Home** (`/`): Scroll down to show the **Recently Viewed** section populated via the `recently_viewed` HTTP cookie set by the view.

### ⏱️ Minute 4: Booking Workflow, Validation & PRG Pattern
- **Navigate to:** Any listing and click **Book Now** while logged out.
- **Show:** Automatic redirect to `/login/?next=...` via `@login_required`.
- **Login as:** `traveler1` / `traveler123!`.
- **Demonstrate Validation:**
  - Try submitting invalid data (e.g., checkout before checkin, or a 5-digit phone). Show the error alerts generated by `BookingForm.clean()`.
  - Submit valid dates (e.g., tomorrow to 3 days later, 2 guests, phone `9876543210`).
- **Show:**
  - The Post/Redirect/Get pattern in action: user is redirected to `/my-bookings/`.
  - A green Django flash message appears (`🎉 Booking confirmed...`).
  - Booking card shows status `⏳ Pending` and the locked-in discounted total price.

### ⏱️ Minute 5: Regex URL, Admin Permissions & Testing Suite
- **Regex URL:** In the browser address bar, visit `/offseason/2025-06/`. Explain that this route is handled by `re_path(r'^offseason/(?P<year>[0-9]{4})-(?P<month>[0-9]{2})/$', ...)`.
- **Admin Panel:**
  - Visit `/admin/` and log in as `manager1` / `manager123!`.
  - Show that as a **Hotel Manager**, the user only sees their own listings (custom `get_queryset` isolation in `ListingAdmin`) and cannot delete or access other models.
- **Run Tests:** Switch to terminal and run `python manage.py test`. Show that all 34 tests pass cleanly.

---

## 🏆 Summary Checklist

- [x] Project name `seasonshift`, app name `tourism`
- [x] Virtual environment `venv` created and tested
- [x] `requirements.txt` with Django
- [x] Clean, well-commented code across all models, views, forms, and templates
- [x] Function-Based Views (FBVs) only
- [x] SQLite database with migrations applied
- [x] Bootstrap 5 via CDN with responsive UI & colored crowd badges
- [x] 12-month crowd calendar with 30%/15%/0% discount logic
- [x] Dynamic month-based pricing with strikethrough original prices
- [x] Post/Redirect/Get booking flow with custom `clean()` validation
- [x] Session-based wishlist & Cookie-based recently viewed listings
- [x] Regex-powered `/offseason/YYYY-MM/` route
- [x] JSON crowd API endpoint (`JsonResponse`)
- [x] Custom `404.html` and `500.html` error pages
- [x] "Hotel Manager" group with custom admin queryset isolation
- [x] 6 realistic Indian destinations with 15 listings seeded
- [x] 34 automated unit and integration tests passing (`OK`)

