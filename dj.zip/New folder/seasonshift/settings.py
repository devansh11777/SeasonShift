"""
seasonshift/settings.py
-----------------------
Main Django configuration for the SeasonShift project.
Each setting is explained with a comment so the student can understand it.
"""

from pathlib import Path

# BASE_DIR points to the root folder of the project (where manage.py lives)
BASE_DIR = Path(__file__).resolve().parent.parent

# SECRET_KEY is used for cryptographic signing – keep it secret in production!
SECRET_KEY = 'django-insecure-seasonshift-university-project-key-2024'

# DEBUG = True shows detailed error pages – turn it OFF in production
DEBUG = True

# Hosts/domains allowed to serve this app. '*' means any host (fine for dev).
ALLOWED_HOSTS = ['*']

# -------------------------------------------------------------------------
# Installed apps – Django modules + our custom tourism app
# -------------------------------------------------------------------------
INSTALLED_APPS = [
    'django.contrib.admin',       # The admin panel
    'django.contrib.auth',        # Authentication (login/logout/users)
    'django.contrib.contenttypes',
    'django.contrib.sessions',    # Session framework (used for wishlist)
    'django.contrib.messages',    # Flash messages (success/error alerts)
    'django.contrib.staticfiles', # Serving static files (CSS, JS, images)
    'tourism',                    # Our main application
]

# -------------------------------------------------------------------------
# Middleware – functions that process every request/response
# -------------------------------------------------------------------------
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',   # Sessions
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',              # CSRF protection
    'django.contrib.auth.middleware.AuthenticationMiddleware',# User auth
    'django.contrib.messages.middleware.MessageMiddleware',   # Flash messages
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

# Root URL configuration file
ROOT_URLCONF = 'seasonshift.urls'

# -------------------------------------------------------------------------
# Template settings – tells Django where to find HTML files
# -------------------------------------------------------------------------
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],  # Look in /templates folder first
        'APP_DIRS': True,                  # Also look in each app's templates/
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',  # Needed for auth
                'django.contrib.auth.context_processors.auth', # Passes user to templates
                'django.contrib.messages.context_processors.messages', # Flash messages
            ],
        },
    },
]

WSGI_APPLICATION = 'seasonshift.wsgi.application'

# -------------------------------------------------------------------------
# Database – using SQLite (a simple file-based database, great for learning)
# -------------------------------------------------------------------------
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',  # Database file in root folder
    }
}

# -------------------------------------------------------------------------
# Password validation rules
# -------------------------------------------------------------------------
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# Language and timezone settings
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Kolkata'  # Indian timezone for our India-based tourism app
USE_I18N = True
USE_TZ = True

# Static files URL prefix
STATIC_URL = 'static/'

# Default primary key type for models
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# -------------------------------------------------------------------------
# Authentication URL settings
# LOGIN_URL       – where to redirect if @login_required fails
# LOGIN_REDIRECT  – where to go after successful login
# LOGOUT_REDIRECT – where to go after logout
# -------------------------------------------------------------------------
LOGIN_URL = '/login/'
LOGIN_REDIRECT_URL = '/'
LOGOUT_REDIRECT_URL = '/'

# -------------------------------------------------------------------------
# LOGGING – prints WARNING and above messages to the console.
# Useful during development to spot problems without looking at error pages.
# -------------------------------------------------------------------------
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,  # Keep Django's built-in loggers active
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',  # Print to terminal
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'WARNING',  # Show WARNING, ERROR, CRITICAL messages
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'WARNING',
            'propagate': False,
        },
        'tourism': {                    # Our app's own logger
            'handlers': ['console'],
            'level': 'DEBUG',           # Show all messages from our app
            'propagate': False,
        },
    },
}

