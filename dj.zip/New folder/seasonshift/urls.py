"""
seasonshift/urls.py
-------------------
Root URL configuration. Maps URL patterns to the tourism app's urls.py.
"""

from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),         # Django admin at /admin/
    path('', include('tourism.urls')),       # Everything else goes to our app
]

# -------------------------------------------------------------------------
# Custom error handlers – Django looks for these names automatically
# -------------------------------------------------------------------------
handler404 = 'tourism.views.custom_404'
handler500 = 'tourism.views.custom_500'

