"""
seasonshift/wsgi.py
-------------------
WSGI entry point – used by web servers like Gunicorn in production.
For development, 'python manage.py runserver' uses this internally.
"""

import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'seasonshift.settings')
application = get_wsgi_application()

