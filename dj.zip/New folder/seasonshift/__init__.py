# seasonshift/__init__.py
# This empty file tells Python that 'seasonshift' is a package.

