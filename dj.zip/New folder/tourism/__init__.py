# tourism/__init__.py
# This empty file makes 'tourism' a Python package / Django app.

