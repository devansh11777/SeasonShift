"""
tourism/apps.py
---------------
App configuration for the 'tourism' app.
Django uses this to register and configure the app.
"""

from django.apps import AppConfig


class TourismConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tourism'
    verbose_name = 'SeasonShift Tourism'  # Human-friendly name shown in admin

