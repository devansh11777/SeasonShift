"""
tourism/urls.py
---------------
URL patterns for the tourism app.

Each path() maps a URL to a view function.
re_path() uses a regular expression – used for the /offseason/ URL.
"""

from django.urls import path, re_path
from . import views

urlpatterns = [
    # -------------------------------------------------------------------------
    # Home
    # -------------------------------------------------------------------------
    path('', views.home, name='home'),

    # -------------------------------------------------------------------------
    # Destinations
    # -------------------------------------------------------------------------
    path('destinations/', views.destination_list, name='destination_list'),
    path('destination/<int:dest_id>/', views.destination_detail, name='destination_detail'),

    # -------------------------------------------------------------------------
    # Listings
    # -------------------------------------------------------------------------
    path('listing/<int:listing_id>/', views.listing_detail, name='listing_detail'),
    path('listing/<int:listing_id>/book/', views.book_listing, name='book_listing'),

    # -------------------------------------------------------------------------
    # My Bookings
    # -------------------------------------------------------------------------
    path('my-bookings/', views.my_bookings, name='my_bookings'),

    # -------------------------------------------------------------------------
    # Off-Season Deals  –  re_path with named regex groups
    # Matches URLs like /offseason/2024-06/  or  /offseason/2025-12/
    # (?P<year>[0-9]{4}) captures exactly 4 digits as 'year'
    # (?P<month>[0-9]{2}) captures exactly 2 digits as 'month'
    # -------------------------------------------------------------------------
    re_path(
        r'^offseason/(?P<year>[0-9]{4})-(?P<month>[0-9]{2})/$',
        views.offseason_deals,
        name='offseason_deals'
    ),

    # -------------------------------------------------------------------------
    # Wishlist  –  stored in Django session
    # -------------------------------------------------------------------------
    path('wishlist/', views.wishlist_view, name='wishlist'),
    path('wishlist/add/<int:listing_id>/', views.wishlist_add, name='wishlist_add'),
    path('wishlist/remove/<int:listing_id>/', views.wishlist_remove, name='wishlist_remove'),

    # -------------------------------------------------------------------------
    # Authentication
    # -------------------------------------------------------------------------
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # -------------------------------------------------------------------------
    # JSON API endpoint – demonstrates JsonResponse
    # -------------------------------------------------------------------------
    path('api/crowd/<int:dest_id>/<int:month>/', views.api_crowd, name='api_crowd'),
]

