"""
tourism/forms.py
----------------
Django forms for SeasonShift.

Forms defined here:
  RegistrationForm  – Sign-up form built on Django's UserCreationForm
  DestinationSearchForm – Simple search/filter form for the destination list
  BookingForm       – Model form for creating a booking with custom validation
"""

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.utils import timezone

from .models import Booking


# =============================================================================
# RegistrationForm
# Extends Django's built-in UserCreationForm to add an email field.
# =============================================================================
class RegistrationForm(UserCreationForm):
    # Add an email field that is required
    email = forms.EmailField(required=True, help_text='Required. Enter a valid email address.')

    class Meta:
        model = User
        # Fields shown on the registration page
        fields = ['username', 'email', 'password1', 'password2']

    def save(self, commit=True):
        """Override save() to also store the email address."""
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user


# =============================================================================
# DestinationSearchForm
# A plain Form (not a ModelForm) used to filter the destination list page.
# =============================================================================
class DestinationSearchForm(forms.Form):
    # Text search by destination name
    name = forms.CharField(
        required=False,
        label='Search destination',
        widget=forms.TextInput(attrs={
            'placeholder': 'e.g. Goa, Manali…',
            'class': 'form-control',
        })
    )

    # Optional month filter (1–12) with a "All months" blank option
    month = forms.ChoiceField(
        required=False,
        label='Month',
        choices=[('', 'All months')] + [(str(i), timezone.datetime(2000, i, 1).strftime('%B')) for i in range(1, 13)],
        widget=forms.Select(attrs={'class': 'form-select'})
    )


# =============================================================================
# BookingForm
# A ModelForm for the Booking model.
# It includes several custom validation methods (clean_* and clean).
# =============================================================================
class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        # We show these fields to the user; final_price and status are set by the view
        fields = ['check_in', 'check_out', 'guests', 'phone']
        widgets = {
            # Date pickers use HTML5 date input
            'check_in': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'check_out': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'guests': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'max': 10}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '10-digit phone number'}),
        }

    # -------------------------------------------------------------------
    # clean_check_in – runs automatically when form.is_valid() is called
    # -------------------------------------------------------------------
    def clean_check_in(self):
        """check_in cannot be in the past."""
        check_in = self.cleaned_data.get('check_in')
        if check_in and check_in < timezone.now().date():
            raise forms.ValidationError("Check-in date cannot be in the past.")
        return check_in

    # -------------------------------------------------------------------
    # clean_guests – guests must be between 1 and 10
    # -------------------------------------------------------------------
    def clean_guests(self):
        """guests must be between 1 and 10."""
        guests = self.cleaned_data.get('guests')
        if guests is not None:
            if guests < 1 or guests > 10:
                raise forms.ValidationError("Number of guests must be between 1 and 10.")
        return guests

    # -------------------------------------------------------------------
    # clean_phone – phone must be exactly 10 digits
    # -------------------------------------------------------------------
    def clean_phone(self):
        """Phone number must be exactly 10 digits."""
        phone = self.cleaned_data.get('phone', '')
        # Remove spaces just in case the user typed them
        phone = phone.strip().replace(' ', '')
        if not phone.isdigit() or len(phone) != 10:
            raise forms.ValidationError("Phone number must be exactly 10 digits (numbers only).")
        return phone

    # -------------------------------------------------------------------
    # clean – cross-field validation (needs both check_in and check_out)
    # -------------------------------------------------------------------
    def clean(self):
        """check_out must be after check_in."""
        cleaned_data = super().clean()
        check_in = cleaned_data.get('check_in')
        check_out = cleaned_data.get('check_out')

        if check_in and check_out:
            if check_out <= check_in:
                raise forms.ValidationError("Check-out date must be after check-in date.")
        return cleaned_data

