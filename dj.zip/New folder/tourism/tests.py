"""
tourism/tests.py
----------------
Automated test suite for SeasonShift.

Tests are grouped into:
  1. Model Tests  – Test discount calculations and price computations
  2. Form Tests   – Test BookingForm validation rules
  3. View Tests   – Test HTTP responses, redirects, login requirements, wishlist

Run with:  python manage.py test
"""

from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import date, timedelta
from decimal import Decimal

from .models import Destination, MonthlyCrowd, Listing, Booking


# =============================================================================
# Helper: Create test objects reused across multiple test cases
# =============================================================================
def create_test_destination():
    """Create a sample destination for testing."""
    return Destination.objects.create(
        name='Test Beach',
        state='Test State',
        description='A beautiful test beach.',
        image_url='https://example.com/test.jpg'
    )


def create_test_listing(destination, owner):
    """Create a sample listing for testing."""
    return Listing.objects.create(
        destination=destination,
        owner=owner,
        title='Test Hotel',
        listing_type='Hotel',
        base_price=Decimal('1000.00'),
        description='A comfortable test hotel.'
    )


# =============================================================================
# 1. MODEL TESTS
# =============================================================================
class DestinationModelTest(TestCase):
    """Tests for the Destination and MonthlyCrowd models."""

    def setUp(self):
        """setUp runs before each test method. Creates fresh test data."""
        self.destination = create_test_destination()
        self.owner = User.objects.create_user(
            username='testowner',
            password='testpass123'
        )
        self.listing = create_test_listing(self.destination, self.owner)

    def test_destination_str(self):
        """__str__ should return 'Name, State'."""
        self.assertEqual(str(self.destination), 'Test Beach, Test State')

    def test_listing_str(self):
        """__str__ should include title and destination."""
        self.assertIn('Test Hotel', str(self.listing))

    # -----------------------------------------------------------------
    # Discount percentage tests
    # -----------------------------------------------------------------
    def test_discount_low_crowd_is_30(self):
        """
        When crowd level is Low, discount should be 30%.
        This is the core off-season incentive logic.
        """
        MonthlyCrowd.objects.create(
            destination=self.destination,
            month=6,
            crowd_level='Low'
        )
        self.assertEqual(self.listing.get_discount_percent(6), 30)

    def test_discount_medium_crowd_is_15(self):
        """When crowd level is Medium, discount should be 15%."""
        MonthlyCrowd.objects.create(
            destination=self.destination,
            month=4,
            crowd_level='Medium'
        )
        self.assertEqual(self.listing.get_discount_percent(4), 15)

    def test_discount_high_crowd_is_0(self):
        """When crowd level is High (peak season), discount should be 0%."""
        MonthlyCrowd.objects.create(
            destination=self.destination,
            month=12,
            crowd_level='High'
        )
        self.assertEqual(self.listing.get_discount_percent(12), 0)

    def test_discount_no_crowd_data_is_0(self):
        """When no MonthlyCrowd record exists, discount should be 0."""
        self.assertEqual(self.listing.get_discount_percent(7), 0)

    # -----------------------------------------------------------------
    # Final price calculation tests
    # -----------------------------------------------------------------
    def test_price_for_low_crowd_month(self):
        """
        For Low crowd: final price = base_price * 0.70
        1000 * 0.70 = 700.00
        """
        MonthlyCrowd.objects.create(
            destination=self.destination,
            month=6,
            crowd_level='Low'
        )
        price = self.listing.get_price_for_month(6)
        self.assertEqual(price, Decimal('700.00'))

    def test_price_for_medium_crowd_month(self):
        """
        For Medium crowd: final price = base_price * 0.85
        1000 * 0.85 = 850.00
        """
        MonthlyCrowd.objects.create(
            destination=self.destination,
            month=4,
            crowd_level='Medium'
        )
        price = self.listing.get_price_for_month(4)
        self.assertEqual(price, Decimal('850.00'))

    def test_price_for_high_crowd_month(self):
        """
        For High crowd (peak): final price = base_price * 1.00 = 1000.00
        """
        MonthlyCrowd.objects.create(
            destination=self.destination,
            month=12,
            crowd_level='High'
        )
        price = self.listing.get_price_for_month(12)
        self.assertEqual(price, Decimal('1000.00'))

    def test_monthly_crowd_unique_together(self):
        """
        Cannot create two MonthlyCrowd records for the same destination+month.
        """
        from django.db import IntegrityError
        MonthlyCrowd.objects.create(
            destination=self.destination,
            month=1,
            crowd_level='Low'
        )
        with self.assertRaises(IntegrityError):
            MonthlyCrowd.objects.create(
                destination=self.destination,
                month=1,
                crowd_level='High'
            )


# =============================================================================
# 2. FORM TESTS
# =============================================================================
class BookingFormTest(TestCase):
    """Tests for BookingForm validation."""

    def get_valid_form_data(self):
        """Return a dict of valid form data."""
        tomorrow = date.today() + timedelta(days=1)
        day_after = date.today() + timedelta(days=3)
        return {
            'check_in': tomorrow.isoformat(),
            'check_out': day_after.isoformat(),
            'guests': 2,
            'phone': '9876543210',
        }

    def test_valid_form(self):
        """A form with correct data should be valid."""
        from .forms import BookingForm
        form = BookingForm(data=self.get_valid_form_data())
        self.assertTrue(form.is_valid(), msg=f"Form errors: {form.errors}")

    def test_invalid_past_check_in(self):
        """check_in in the past should fail validation."""
        from .forms import BookingForm
        data = self.get_valid_form_data()
        data['check_in'] = (date.today() - timedelta(days=1)).isoformat()
        form = BookingForm(data=data)
        self.assertFalse(form.is_valid())
        self.assertIn('check_in', form.errors)

    def test_checkout_before_checkin(self):
        """check_out on the same day or before check_in should fail."""
        from .forms import BookingForm
        tomorrow = date.today() + timedelta(days=1)
        data = self.get_valid_form_data()
        data['check_in'] = tomorrow.isoformat()
        data['check_out'] = tomorrow.isoformat()  # Same day – invalid
        form = BookingForm(data=data)
        self.assertFalse(form.is_valid())

    def test_checkout_before_checkin_earlier(self):
        """check_out before check_in should fail."""
        from .forms import BookingForm
        data = self.get_valid_form_data()
        # Set check_out before check_in
        data['check_in'] = (date.today() + timedelta(days=5)).isoformat()
        data['check_out'] = (date.today() + timedelta(days=2)).isoformat()
        form = BookingForm(data=data)
        self.assertFalse(form.is_valid())

    def test_invalid_phone_letters(self):
        """Phone with letters should fail."""
        from .forms import BookingForm
        data = self.get_valid_form_data()
        data['phone'] = 'abcde12345'
        form = BookingForm(data=data)
        self.assertFalse(form.is_valid())
        self.assertIn('phone', form.errors)

    def test_invalid_phone_too_short(self):
        """Phone with fewer than 10 digits should fail."""
        from .forms import BookingForm
        data = self.get_valid_form_data()
        data['phone'] = '12345'
        form = BookingForm(data=data)
        self.assertFalse(form.is_valid())
        self.assertIn('phone', form.errors)

    def test_invalid_phone_too_long(self):
        """Phone with more than 10 digits should fail."""
        from .forms import BookingForm
        data = self.get_valid_form_data()
        data['phone'] = '12345678901'  # 11 digits
        form = BookingForm(data=data)
        self.assertFalse(form.is_valid())
        self.assertIn('phone', form.errors)

    def test_guests_zero(self):
        """0 guests should fail (minimum is 1)."""
        from .forms import BookingForm
        data = self.get_valid_form_data()
        data['guests'] = 0
        form = BookingForm(data=data)
        self.assertFalse(form.is_valid())
        self.assertIn('guests', form.errors)

    def test_guests_too_many(self):
        """More than 10 guests should fail."""
        from .forms import BookingForm
        data = self.get_valid_form_data()
        data['guests'] = 11
        form = BookingForm(data=data)
        self.assertFalse(form.is_valid())
        self.assertIn('guests', form.errors)


# =============================================================================
# 3. VIEW TESTS
# =============================================================================
class HomeViewTest(TestCase):
    """Tests for the home page view."""

    def test_home_returns_200(self):
        """Home page should return HTTP 200 OK."""
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)

    def test_home_uses_correct_template(self):
        """Home page should use the tourism/home.html template."""
        response = self.client.get('/')
        self.assertTemplateUsed(response, 'tourism/home.html')


class BookingViewTest(TestCase):
    """Tests for the booking view."""

    def setUp(self):
        """Create destination, listing, and users for booking tests."""
        self.destination = create_test_destination()
        self.owner = User.objects.create_user(
            username='owner', password='ownerpass123'
        )
        self.traveler = User.objects.create_user(
            username='traveler', password='travelerpass123'
        )
        self.listing = create_test_listing(self.destination, self.owner)

        # Add crowd data so price calculation works
        MonthlyCrowd.objects.create(
            destination=self.destination,
            month=date.today().month,
            crowd_level='Low'
        )

    def test_booking_page_redirects_anonymous(self):
        """
        Anonymous (not logged in) users should be redirected to the login page.
        @login_required decorator handles this.
        """
        response = self.client.get(f'/listing/{self.listing.id}/book/')
        # Should redirect (302) to the login URL
        self.assertEqual(response.status_code, 302)
        self.assertIn('/login/', response['Location'])

    def test_booking_page_accessible_logged_in(self):
        """A logged-in user should see the booking form (200 OK)."""
        self.client.login(username='traveler', password='travelerpass123')
        response = self.client.get(f'/listing/{self.listing.id}/book/')
        self.assertEqual(response.status_code, 200)

    def test_logged_in_user_can_book_and_redirects(self):
        """
        A logged-in user submitting a valid booking form should:
        1. Create a Booking object in the database
        2. Be redirected to /my-bookings/ (Post/Redirect/Get pattern)
        """
        self.client.login(username='traveler', password='travelerpass123')
        tomorrow = date.today() + timedelta(days=1)
        day_after = date.today() + timedelta(days=3)

        response = self.client.post(
            f'/listing/{self.listing.id}/book/',
            {
                'check_in': tomorrow.isoformat(),
                'check_out': day_after.isoformat(),
                'guests': 2,
                'phone': '9876543210',
            }
        )

        # Should redirect to my-bookings
        self.assertRedirects(response, '/my-bookings/')

        # Check that a booking was actually created in the database
        self.assertEqual(Booking.objects.filter(user=self.traveler).count(), 1)

    def test_nonexistent_listing_returns_404(self):
        """Requesting a listing that doesn't exist should return 404."""
        response = self.client.get('/listing/99999/')
        self.assertEqual(response.status_code, 404)

    def test_nonexistent_destination_returns_404(self):
        """Requesting a destination that doesn't exist should return 404."""
        response = self.client.get('/destination/99999/')
        self.assertEqual(response.status_code, 404)


class WishlistViewTest(TestCase):
    """Tests for the session-based wishlist."""

    def setUp(self):
        self.destination = create_test_destination()
        self.owner = User.objects.create_user(
            username='owner2', password='ownerpass123'
        )
        self.listing = create_test_listing(self.destination, self.owner)

    def test_wishlist_page_accessible(self):
        """Wishlist page should be accessible to all users (no login required)."""
        response = self.client.get('/wishlist/')
        self.assertEqual(response.status_code, 200)

    def test_wishlist_add_stores_in_session(self):
        """
        Adding a listing to the wishlist should store its ID in the session.
        """
        response = self.client.get(f'/wishlist/add/{self.listing.id}/')

        # Check that the listing ID is now in the session
        wishlist = self.client.session.get('wishlist', [])
        self.assertIn(self.listing.id, wishlist)

    def test_wishlist_add_duplicate_not_stored_twice(self):
        """Adding the same listing twice should not create duplicates."""
        self.client.get(f'/wishlist/add/{self.listing.id}/')
        self.client.get(f'/wishlist/add/{self.listing.id}/')

        wishlist = self.client.session.get('wishlist', [])
        self.assertEqual(wishlist.count(self.listing.id), 1)

    def test_wishlist_remove_deletes_from_session(self):
        """Removing a listing should delete it from the session."""
        # First add it
        self.client.get(f'/wishlist/add/{self.listing.id}/')
        # Then remove it
        self.client.get(f'/wishlist/remove/{self.listing.id}/')

        wishlist = self.client.session.get('wishlist', [])
        self.assertNotIn(self.listing.id, wishlist)


class OffseasonViewTest(TestCase):
    """Tests for the regex-based offseason deals view."""

    def test_offseason_url_resolves(self):
        """The re_path offseason URL should return 200."""
        response = self.client.get('/offseason/2025-06/')
        self.assertEqual(response.status_code, 200)

    def test_offseason_invalid_month_returns_400(self):
        """Month 13 is invalid – should return 400."""
        response = self.client.get('/offseason/2025-13/')
        self.assertEqual(response.status_code, 400)


class ApiCrowdTest(TestCase):
    """Tests for the JSON crowd API endpoint."""

    def setUp(self):
        self.destination = create_test_destination()
        MonthlyCrowd.objects.create(
            destination=self.destination,
            month=1,
            crowd_level='High'
        )

    def test_api_crowd_returns_json(self):
        """API endpoint should return JSON with crowd level."""
        import json
        response = self.client.get(f'/api/crowd/{self.destination.id}/1/')
        self.assertEqual(response.status_code, 200)
        # Check Content-Type is JSON
        self.assertEqual(response['Content-Type'], 'application/json')
        data = json.loads(response.content)
        self.assertEqual(data['crowd_level'], 'High')
        self.assertEqual(data['destination'], 'Test Beach')

    def test_api_crowd_nonexistent_destination(self):
        """API with invalid destination ID should return 404."""
        response = self.client.get('/api/crowd/99999/1/')
        self.assertEqual(response.status_code, 404)

