"""
tourism/admin.py
----------------
Registers models in the Django Admin panel.

Features:
  - list_display   : columns shown in the admin list view
  - search_fields  : fields searchable via the search bar
  - list_filter    : sidebar filters
  - MonthlyCrowd   : shown as inline inside Destination admin
  - Hotel Manager  : can only see/edit their own listings
"""

from django.contrib import admin
from .models import Destination, MonthlyCrowd, Listing, Booking


# =============================================================================
# MonthlyCrowd Inline
# Shows MonthlyCrowd entries directly inside the Destination edit page
# so admins can set crowd levels for all 12 months in one place.
# =============================================================================
class MonthlyCrowdInline(admin.TabularInline):
    model = MonthlyCrowd
    extra = 0        # Don't show empty extra rows by default
    ordering = ['month']
    fields = ['month', 'crowd_level']


# =============================================================================
# Destination Admin
# =============================================================================
@admin.register(Destination)
class DestinationAdmin(admin.ModelAdmin):
    list_display = ['name', 'state']
    search_fields = ['name', 'state']
    list_filter = ['state']
    # Embed the monthly crowd table directly in the destination form
    inlines = [MonthlyCrowdInline]


# =============================================================================
# MonthlyCrowd Admin (standalone, in case needed)
# =============================================================================
@admin.register(MonthlyCrowd)
class MonthlyCrowdAdmin(admin.ModelAdmin):
    list_display = ['destination', 'month', 'crowd_level']
    search_fields = ['destination__name']
    list_filter = ['crowd_level', 'month']


# =============================================================================
# Listing Admin
# Hotel Managers can only see and edit their own listings.
# This is enforced by overriding get_queryset and save_model.
# =============================================================================
@admin.register(Listing)
class ListingAdmin(admin.ModelAdmin):
    list_display = ['title', 'listing_type', 'destination', 'owner', 'base_price']
    search_fields = ['title', 'destination__name', 'owner__username']
    list_filter = ['listing_type', 'destination']

    def get_queryset(self, request):
        """
        Superusers see all listings.
        Hotel Managers see only listings they own.
        """
        qs = super().get_queryset(request)
        if request.user.is_superuser:
            return qs  # Superuser gets everything
        # Hotel Manager filter: only their own listings
        return qs.filter(owner=request.user)

    def save_model(self, request, obj, form, change):
        """
        When a Hotel Manager creates a listing, automatically set owner to themselves.
        Prevents them from assigning listings to other users.
        """
        if not request.user.is_superuser:
            obj.owner = request.user  # Force owner to be the logged-in manager
        super().save_model(request, obj, form, change)


# =============================================================================
# Booking Admin
# =============================================================================
@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'listing', 'check_in', 'check_out', 'guests', 'final_price', 'status', 'created_at']
    search_fields = ['user__username', 'listing__title']
    list_filter = ['status', 'created_at']
    readonly_fields = ['created_at']  # Don't allow editing the timestamp

