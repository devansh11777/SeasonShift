"""
tourism/views.py
----------------
All function-based views for the SeasonShift tourism platform.

Each view function:
  1. Receives an HttpRequest object
  2. Does some processing (querying the DB, handling forms, etc.)
  3. Returns an HttpResponse (usually by rendering a template)

Views defined:
  home                – Landing page
  destination_list    – Browse/search destinations
  destination_detail  – Full destination page with crowd calendar
  listing_detail      – Listing page showing price and discount
  book_listing        – Booking form (login required)
  my_bookings         – User's booking history (login required)
  offseason_deals     – Listings with discounts for a given year-month (regex URL demo)
  wishlist_view       – Show saved wishlist
  wishlist_add        – Add listing to session wishlist
  wishlist_remove     – Remove listing from session wishlist
  register_view       – User registration
  login_view          – User login
  logout_view         – User logout
  api_crowd           – JSON endpoint returning crowd level for a destination/month
  custom_404          – Custom 404 error page
  custom_500          – Custom 500 error page
"""

import json
import logging

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .forms import BookingForm, DestinationSearchForm, RegistrationForm
from .models import Booking, Destination, Listing, MonthlyCrowd

# Get a logger for this module – messages will appear in the console
logger = logging.getLogger('tourism')

# Month names list – used to display month names in templates
MONTH_NAMES = [
    '', 'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
]


# =============================================================================
# HOME VIEW  –  GET /
# Shows featured destinations and explains the off-season concept.
# Also reads recently viewed listings from a cookie.
# =============================================================================
def home(request):
    """Landing page – shows featured destinations and recently viewed listings."""

    # Grab 6 destinations to show as featured cards
    featured_destinations = Destination.objects.all()[:6]

    # Read recently viewed listing IDs from the cookie
    # Cookies are plain strings, so we store them as comma-separated IDs
    recent_ids_raw = request.COOKIES.get('recently_viewed', '')
    recent_listings = []
    if recent_ids_raw:
        try:
            # Split cookie string into list of integer IDs
            recent_ids = [int(x) for x in recent_ids_raw.split(',') if x.strip().isdigit()]
            # Fetch those listings in order, preserving cookie order
            id_to_listing = {l.id: l for l in Listing.objects.filter(id__in=recent_ids)}
            recent_listings = [id_to_listing[i] for i in recent_ids if i in id_to_listing]
        except (ValueError, Exception) as e:
            logger.warning("Could not parse recently_viewed cookie: %s", e)

    context = {
        'featured_destinations': featured_destinations,
        'recent_listings': recent_listings,
    }
    return render(request, 'tourism/home.html', context)


# =============================================================================
# DESTINATION LIST VIEW  –  GET /destinations/
# Lists all destinations; supports search by name and filter by month.
# =============================================================================
def destination_list(request):
    """Show all destinations; allow search by name and filter by month."""

    # Pass GET data into our search form
    form = DestinationSearchForm(request.GET)
    destinations = Destination.objects.all()

    name_query = ''
    month_query = ''

    if form.is_valid():
        name_query = form.cleaned_data.get('name', '')
        month_query = form.cleaned_data.get('month', '')

        # Filter by name (case-insensitive contains search)
        if name_query:
            destinations = destinations.filter(name__icontains=name_query)

        # Filter by month – only show destinations that have crowd data for that month
        if month_query:
            destinations = destinations.filter(
                crowd_levels__month=int(month_query)
            ).distinct()

    context = {
        'form': form,
        'destinations': destinations,
        'name_query': name_query,
        'month_query': month_query,
    }
    return render(request, 'tourism/destination_list.html', context)


# =============================================================================
# DESTINATION DETAIL VIEW  –  GET /destination/<dest_id>/
# Shows full destination info, a 12-month crowd calendar, and all listings.
# =============================================================================
def destination_detail(request, dest_id):
    """Show destination details with crowd calendar and listings."""

    # get_object_or_404 returns the object or raises a 404 if not found
    destination = get_object_or_404(Destination, pk=dest_id)

    # Build a crowd calendar: list of dicts with month, name, and crowd level
    crowd_data = {
        c.month: c.crowd_level
        for c in destination.crowd_levels.all()
    }
    crowd_calendar = []
    for month_num in range(1, 13):
        crowd_calendar.append({
            'month': month_num,
            'month_name': MONTH_NAMES[month_num],
            'crowd_level': crowd_data.get(month_num, 'N/A'),
        })

    # All listings at this destination
    listings = destination.listings.all()

    context = {
        'destination': destination,
        'crowd_calendar': crowd_calendar,
        'listings': listings,
        'month_names': MONTH_NAMES,
    }
    return render(request, 'tourism/destination_detail.html', context)


# =============================================================================
# LISTING DETAIL VIEW  –  GET /listing/<listing_id>/?month=<1-12>
# Shows listing info, the base price, discount, and final price for a month.
# Also sets a cookie to track recently viewed listings.
# =============================================================================
def listing_detail(request, listing_id):
    """Show listing details with optional month-based pricing."""

    listing = get_object_or_404(Listing, pk=listing_id)

    # Read 'month' from query string; default to current month
    try:
        month = int(request.GET.get('month', timezone.now().month))
        if month < 1 or month > 12:
            month = timezone.now().month
    except (ValueError, TypeError):
        month = timezone.now().month

    # Calculate discount and final price using our model methods
    discount_percent = listing.get_discount_percent(month)
    final_price = listing.get_price_for_month(month)

    # Get crowd level for this month
    try:
        crowd = MonthlyCrowd.objects.get(destination=listing.destination, month=month)
        crowd_level = crowd.crowd_level
    except MonthlyCrowd.DoesNotExist:
        crowd_level = 'N/A'

    context = {
        'listing': listing,
        'month': month,
        'month_name': MONTH_NAMES[month],
        'discount_percent': discount_percent,
        'final_price': final_price,
        'crowd_level': crowd_level,
        'month_range': range(1, 13),
        'month_names': MONTH_NAMES,
        # month_choices: list of (number, name) tuples for the dropdown
        'month_choices': [(i, MONTH_NAMES[i]) for i in range(1, 13)],
    }

    # Render the template first, then modify the response to set a cookie
    response = render(request, 'tourism/listing_detail.html', context)

    # -----------------------------------------------------------------
    # Set "recently_viewed" cookie
    # We store a comma-separated list of listing IDs (max 5)
    # -----------------------------------------------------------------
    recent_ids_raw = request.COOKIES.get('recently_viewed', '')
    recent_ids = [x for x in recent_ids_raw.split(',') if x.strip().isdigit()]

    # Remove current listing if already in the list (avoid duplicates)
    str_id = str(listing_id)
    if str_id in recent_ids:
        recent_ids.remove(str_id)

    # Add current listing to front of list
    recent_ids.insert(0, str_id)

    # Keep only the 5 most recent
    recent_ids = recent_ids[:5]

    # Set cookie that expires in 7 days (7*24*60*60 seconds)
    response.set_cookie('recently_viewed', ','.join(recent_ids), max_age=7 * 24 * 60 * 60)

    return response


# =============================================================================
# BOOK LISTING VIEW  –  GET/POST /listing/<listing_id>/book/
# Shows and processes the booking form. Login is required.
# Uses Post/Redirect/Get pattern after successful booking.
# =============================================================================
@login_required  # Redirects to LOGIN_URL if user is not authenticated
def book_listing(request, listing_id):
    """Display booking form and process booking submission."""

    listing = get_object_or_404(Listing, pk=listing_id)

    # Get month from query string to pre-calculate price
    try:
        month = int(request.GET.get('month', timezone.now().month))
        if month < 1 or month > 12:
            month = timezone.now().month
    except (ValueError, TypeError):
        month = timezone.now().month

    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            # Don't save to DB yet – we need to set extra fields
            booking = form.save(commit=False)
            booking.user = request.user      # Set the logged-in user
            booking.listing = listing         # Set the listing

            # Calculate final price based on check-in month
            check_in_month = booking.check_in.month
            booking.final_price = listing.get_price_for_month(check_in_month)

            booking.status = 'Pending'       # Default status
            booking.save()                    # Now save to database

            # Django messages framework – shows a green success banner
            messages.success(
                request,
                f"🎉 Booking confirmed for {listing.title}! "
                f"Your booking ID is #{booking.pk}. Status: Pending."
            )
            logger.info("New booking #%d created by user %s", booking.pk, request.user.username)

            # POST/Redirect/GET – redirect to my-bookings to avoid re-submission on refresh
            return redirect('my_bookings')
        else:
            # Form has errors – show them to the user
            messages.error(request, "Please fix the errors below and try again.")
    else:
        # GET request – show empty booking form
        form = BookingForm()

    # Pre-calculate price so user can see it before submitting
    final_price = listing.get_price_for_month(month)
    discount_percent = listing.get_discount_percent(month)

    context = {
        'form': form,
        'listing': listing,
        'month': month,
        'month_name': MONTH_NAMES[month],
        'final_price': final_price,
        'discount_percent': discount_percent,
    }
    return render(request, 'tourism/book_listing.html', context)


# =============================================================================
# MY BOOKINGS VIEW  –  GET /my-bookings/
# Shows all bookings for the currently logged-in user. Login required.
# =============================================================================
@login_required
def my_bookings(request):
    """Show all bookings for the logged-in user."""
    bookings = Booking.objects.filter(user=request.user).select_related('listing__destination')
    context = {'bookings': bookings}
    return render(request, 'tourism/my_bookings.html', context)


# =============================================================================
# OFF-SEASON DEALS VIEW  –  GET /offseason/<year>-<month>/
# Uses a regex URL to capture year and month.
# Lists all listings that have a discount (Low or Medium crowd) for that month.
# =============================================================================
def offseason_deals(request, year, month):
    """
    Show all listings with an off-season discount for the given year-month.
    This view demonstrates the use of re_path with named regex groups.
    year and month arrive as strings from the URL regex.
    """
    # Convert to integers
    month_int = int(month)
    year_int = int(year)

    # Validate month range
    if not (1 <= month_int <= 12):
        return HttpResponse("Invalid month. Please use 01-12.", status=400)

    # Find destinations that have Low or Medium crowd in this month
    discounted_destinations = Destination.objects.filter(
        crowd_levels__month=month_int,
        crowd_levels__crowd_level__in=['Low', 'Medium']
    ).distinct()

    # Get listings for those destinations, with their discount info attached
    deals = []
    for listing in Listing.objects.filter(destination__in=discounted_destinations):
        discount = listing.get_discount_percent(month_int)
        if discount > 0:
            deals.append({
                'listing': listing,
                'discount': discount,
                'final_price': listing.get_price_for_month(month_int),
            })

    # Sort by discount (highest first)
    deals.sort(key=lambda x: x['discount'], reverse=True)

    context = {
        'deals': deals,
        'month': month_int,
        'month_name': MONTH_NAMES[month_int],
        'year': year_int,
    }
    return render(request, 'tourism/offseason_deals.html', context)


# =============================================================================
# WISHLIST VIEWS  –  Stored in Django session (server-side, per-user)
# /wishlist/               – View the wishlist
# /wishlist/add/<id>/      – Add a listing
# /wishlist/remove/<id>/   – Remove a listing
# =============================================================================
def wishlist_view(request):
    """Display all listings saved in the session wishlist."""
    # Session stores wishlist as a list of listing IDs
    wishlist_ids = request.session.get('wishlist', [])
    listings = Listing.objects.filter(id__in=wishlist_ids).select_related('destination')
    context = {'listings': listings, 'wishlist_ids': wishlist_ids}
    return render(request, 'tourism/wishlist.html', context)


def wishlist_add(request, listing_id):
    """Add a listing to the session wishlist."""
    # get_object_or_404 ensures the listing exists
    listing = get_object_or_404(Listing, pk=listing_id)

    # Get current wishlist from session, or start with empty list
    wishlist = request.session.get('wishlist', [])

    if listing_id not in wishlist:
        wishlist.append(listing_id)
        request.session['wishlist'] = wishlist  # Save back to session
        messages.success(request, f'"{listing.title}" added to your wishlist!')
    else:
        messages.info(request, f'"{listing.title}" is already in your wishlist.')

    # Redirect back to whichever page the user came from (or listing detail)
    return redirect(request.META.get('HTTP_REFERER', 'wishlist'))


def wishlist_remove(request, listing_id):
    """Remove a listing from the session wishlist."""
    wishlist = request.session.get('wishlist', [])
    if listing_id in wishlist:
        wishlist.remove(listing_id)
        request.session['wishlist'] = wishlist
        messages.success(request, 'Listing removed from wishlist.')
    return redirect('wishlist')


# =============================================================================
# AUTHENTICATION VIEWS  –  /register/, /login/, /logout/
# =============================================================================
def register_view(request):
    """Handle user registration."""
    # Redirect already-logged-in users to home
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Automatically log in the new user
            login(request, user)
            messages.success(request, f"Welcome to SeasonShift, {user.username}! 🌴")
            return redirect('home')
    else:
        form = RegistrationForm()

    return render(request, 'tourism/register.html', {'form': form})


def login_view(request):
    """Handle user login."""
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f"Welcome back, {user.username}! 👋")
            # Redirect to 'next' parameter if present (from @login_required), else home
            next_url = request.POST.get('next', request.GET.get('next', 'home'))
            return redirect(next_url)
        else:
            messages.error(request, "Invalid username or password. Please try again.")

    return render(request, 'tourism/login.html', {
        'next': request.GET.get('next', '')
    })


def logout_view(request):
    """Log out the current user and redirect to home."""
    logout(request)
    messages.info(request, "You have been logged out. See you again! 👋")
    return redirect('home')


# =============================================================================
# API ENDPOINT  –  GET /api/crowd/<dest_id>/<month>/
# Returns JSON response – demonstrates JsonResponse usage.
# =============================================================================
def api_crowd(request, dest_id, month):
    """
    Returns the crowd level for a destination and month as JSON.
    Example response: {"destination": "Goa", "month": 1, "crowd_level": "High"}
    This demonstrates Django's JsonResponse class.
    """
    destination = get_object_or_404(Destination, pk=dest_id)

    if not (1 <= month <= 12):
        return JsonResponse({'error': 'Month must be between 1 and 12'}, status=400)

    try:
        crowd = MonthlyCrowd.objects.get(destination=destination, month=month)
        crowd_level = crowd.crowd_level
    except MonthlyCrowd.DoesNotExist:
        crowd_level = None

    # JsonResponse automatically converts the dict to JSON and sets Content-Type
    return JsonResponse({
        'destination': destination.name,
        'state': destination.state,
        'month': month,
        'month_name': MONTH_NAMES[month],
        'crowd_level': crowd_level,
    })


# =============================================================================
# CUSTOM ERROR HANDLERS
# Django calls these functions when errors occur (if DEBUG = False or in tests).
# =============================================================================
def custom_404(request, exception):
    """Custom 404 page – shown when a URL is not found."""
    return render(request, '404.html', status=404)


def custom_500(request):
    """Custom 500 page – shown when a server error occurs."""
    return render(request, '500.html', status=500)
