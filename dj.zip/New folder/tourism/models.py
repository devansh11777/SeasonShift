"""
tourism/models.py
-----------------
Defines the database tables (models) for the SeasonShift tourism platform.

Models:
  Destination   – A tourist place (Goa, Manali, etc.)
  MonthlyCrowd  – How crowded a destination is each month
  Listing       – A hotel or travel package at a destination
  Booking       – A reservation made by a user for a listing
"""

from decimal import Decimal

from django.db import models
from django.contrib.auth.models import User


# =============================================================================
# Destination Model
# Represents a tourist destination like Goa, Manali, Jaipur, etc.
# =============================================================================
class Destination(models.Model):
    # Name of the destination (e.g., "Goa", "Manali")
    name = models.CharField(max_length=200)

    # Which Indian state it belongs to
    state = models.CharField(max_length=100)

    # A paragraph describing the destination for the detail page
    description = models.TextField()

    # URL to a banner/thumbnail image (we store the URL, not the file itself)
    image_url = models.URLField(max_length=500, blank=True)

    class Meta:
        ordering = ['name']  # Sort alphabetically by default

    def __str__(self):
        # This shows up in the admin and anywhere Python prints the object
        return f"{self.name}, {self.state}"


# =============================================================================
# MonthlyCrowd Model
# Stores how crowded a destination is for each month of the year.
# This is the core data that drives discount calculations.
# =============================================================================
class MonthlyCrowd(models.Model):
    # Crowd level choices – shown as a dropdown in forms and admin
    CROWD_CHOICES = [
        ('Low', 'Low'),
        ('Medium', 'Medium'),
        ('High', 'High'),
    ]

    # Link to the destination this crowd data belongs to
    destination = models.ForeignKey(
        Destination,
        on_delete=models.CASCADE,     # If destination is deleted, delete crowd data too
        related_name='crowd_levels'   # Access via destination.crowd_levels.all()
    )

    # Month number: 1 = January, 12 = December
    month = models.IntegerField(
        choices=[(i, i) for i in range(1, 13)]
    )

    # How crowded: Low / Medium / High
    crowd_level = models.CharField(max_length=10, choices=CROWD_CHOICES)

    class Meta:
        # Ensure each destination has only one crowd entry per month
        unique_together = ('destination', 'month')
        ordering = ['destination', 'month']

    def __str__(self):
        return f"{self.destination.name} – Month {self.month}: {self.crowd_level}"


# =============================================================================
# Listing Model
# A hotel or travel package available at a destination.
# Owners (hotel managers) can create their own listings.
# =============================================================================
class Listing(models.Model):
    # Type of listing – helps travelers know what they're booking
    LISTING_TYPE_CHOICES = [
        ('Hotel', 'Hotel'),
        ('Package', 'Package'),
    ]

    # Which destination this listing is for
    destination = models.ForeignKey(
        Destination,
        on_delete=models.CASCADE,
        related_name='listings'
    )

    # The user who created/owns this listing (usually a Hotel Manager)
    owner = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='listings'
    )

    # Short title shown on listing cards
    title = models.CharField(max_length=300)

    # Hotel or Package
    listing_type = models.CharField(max_length=10, choices=LISTING_TYPE_CHOICES)

    # Regular full-price (before any off-season discount)
    base_price = models.DecimalField(max_digits=10, decimal_places=2)

    # Detailed description of what's included
    description = models.TextField()

    class Meta:
        ordering = ['title']

    def __str__(self):
        return f"{self.title} ({self.listing_type}) @ {self.destination.name}"

    def get_discount_percent(self, month):
        """
        Returns the discount percentage for a given month.
        Low crowd  → 30% off  (off-season, attract travelers with discounts)
        Medium     → 15% off
        High crowd →  0% off  (peak season, no need to discount)
        If no crowd data exists for that month, return 0.
        """
        try:
            crowd = MonthlyCrowd.objects.get(
                destination=self.destination,
                month=month
            )
            discount_map = {'Low': 30, 'Medium': 15, 'High': 0}
            return discount_map.get(crowd.crowd_level, 0)
        except MonthlyCrowd.DoesNotExist:
            return 0  # No data → no discount

    def get_price_for_month(self, month):
        """
        Returns the final price after applying the off-season discount.
        Uses Decimal arithmetic to avoid float/Decimal type errors.
        Formula: base_price * (1 - discount_percent / 100)
        """
        discount = self.get_discount_percent(month)
        # Use Decimal() to keep arithmetic compatible with base_price (DecimalField)
        multiplier = Decimal(str(1 - discount / 100))
        discounted = self.base_price * multiplier
        return round(discounted, 2)


# =============================================================================
# Booking Model
# A reservation made by a traveler for a specific listing.
# =============================================================================
class Booking(models.Model):
    # Booking status choices
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Confirmed', 'Confirmed'),
    ]

    # The user who made the booking
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='bookings'
    )

    # The listing being booked
    listing = models.ForeignKey(
        Listing,
        on_delete=models.CASCADE,
        related_name='bookings'
    )

    # Travel dates
    check_in = models.DateField()
    check_out = models.DateField()

    # Number of guests
    guests = models.IntegerField()

    # Contact number (stored as string to preserve leading zeros)
    phone = models.CharField(max_length=15)

    # Price calculated at time of booking (locked in – doesn't change later)
    final_price = models.DecimalField(max_digits=10, decimal_places=2)

    # Whether the booking is confirmed or still pending
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Pending')

    # Automatically set when booking is first created
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']  # Newest bookings first

    def __str__(self):
        return f"Booking #{self.pk} – {self.user.username} → {self.listing.title}"
