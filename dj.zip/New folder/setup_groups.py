"""
setup_groups.py
---------------
Creates the 'Hotel Manager' permission group.

Run with:  python manage.py shell < setup_groups.py

The Hotel Manager group can:
  - Add, change, and view Listings
  - View Bookings
  - Cannot delete Listings or access any other model
"""

import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'seasonshift.settings')
django.setup()

from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType
from tourism.models import Listing, Booking

print("🔧 Setting up permission groups...")

# Delete the group if it already exists (allow re-running)
Group.objects.filter(name='Hotel Manager').delete()

# Create the Hotel Manager group
hotel_manager_group = Group.objects.create(name='Hotel Manager')
print("  ✓ Created group: 'Hotel Manager'")

# Get the ContentType for Listing and Booking models
# (Django uses content types to link permissions to models)
listing_ct = ContentType.objects.get_for_model(Listing)
booking_ct = ContentType.objects.get_for_model(Booking)

# Get the specific permissions we want to grant
permissions_to_add = []

# Listing permissions: add, change, view (NOT delete)
for codename in ['add_listing', 'change_listing', 'view_listing']:
    try:
        perm = Permission.objects.get(codename=codename, content_type=listing_ct)
        permissions_to_add.append(perm)
        print(f"  ✓ Found permission: {codename}")
    except Permission.DoesNotExist:
        print(f"  ⚠️  Permission not found: {codename} (run migrate first)")

# Booking permission: view only (Hotel Managers can see bookings for their listings)
try:
    perm = Permission.objects.get(codename='view_booking', content_type=booking_ct)
    permissions_to_add.append(perm)
    print(f"  ✓ Found permission: view_booking")
except Permission.DoesNotExist:
    print(f"  ⚠️  Permission not found: view_booking (run migrate first)")

# Assign all permissions to the group
hotel_manager_group.permissions.set(permissions_to_add)

print(f"\n✅ Group 'Hotel Manager' created with {len(permissions_to_add)} permissions:")
for p in permissions_to_add:
    print(f"   - {p.codename}")

print("\nTo add a user to this group, run:")
print("  from django.contrib.auth.models import User, Group")
print("  user = User.objects.get(username='manager1')")
print("  group = Group.objects.get(name='Hotel Manager')")
print("  user.groups.add(group)")
print("  user.is_staff = True  # Allow admin panel access")
print("  user.save()")

